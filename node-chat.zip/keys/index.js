module.exports = {
    // MONGODB_URI: 'mongodb+srv://vladilen:0I5GEL9uLUcR38GC@cluster0-3rrau.mongodb.net/shop',
    // SESSION_SECRET: 'some secret value',
    // SENDGRID_API_KEY: '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',
    // EMAIL_FROM: 'nodejs@email.ru',
    BASE_URL: 'http://localhost:3000'
  } 